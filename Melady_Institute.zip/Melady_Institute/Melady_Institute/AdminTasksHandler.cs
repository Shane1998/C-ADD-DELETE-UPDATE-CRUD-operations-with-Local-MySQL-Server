﻿using System;
using System.Windows.Forms;

namespace Melady_Institute
{
    public partial class AdminTasksHandlerForm : Form
    {
        public AdminTasksHandlerForm()
        {
            InitializeComponent();
        }

        //Click the button then load MemberHandlingModule
        private void btnMemberHandler_Click(object sender, EventArgs e)
        {
            MemberHandlingForm memberHandlingForm = new MemberHandlingForm();
            this.Hide();
            memberHandlingForm.ShowDialog();
            
            
        }

        //Click the button then load PaymentHandlingModule
        private void btnPaymentHandler_Click(object sender, EventArgs e)
        {
            PaymentHandlingForm paymentHandlingForm = new PaymentHandlingForm();
            this.Hide();
            paymentHandlingForm.ShowDialog();
        }

        //Click the button then load CourseHandlingModule
        private void btnCourseHandler_Click(object sender, EventArgs e)
        {
            CourseHandlingForm courseHandlingForm = new CourseHandlingForm();
            this.Hide();
            courseHandlingForm.ShowDialog();

        }
    }
}
