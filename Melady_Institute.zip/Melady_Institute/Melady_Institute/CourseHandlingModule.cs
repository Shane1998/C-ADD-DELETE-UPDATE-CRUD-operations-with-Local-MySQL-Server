﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Melady_Institute
{
    public partial class CourseHandlingForm : Form
    {
        /*
         *  CourseHandlingForm Define :-
            1. Load the form
            2. Insert course details
            3. Update course details
            4. Delete course details
            5. Search course using courseID
         */

        public CourseHandlingForm()
        {
            InitializeComponent();
        }

        //Connection builder of the database
        SqlConnection sqlConnection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\shane jayasinghe\source\repos\Melady_Institute\Melady_Institute\MeladyDB.mdf; Integrated Security = True");
        DataTable dataTable = new DataTable();

        //CourseHandlingModule Loading
        private void CourseHandlingModule_Load(object sender, EventArgs e)
        {
            getCourseRecords();
        }

        //Get course records from the course table
        private void getCourseRecords()
        {
            SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Course", sqlConnection);

            sqlConnection.Open();

            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dataTable.Load(sqlDataReader);
            sqlConnection.Close();

            CourseDetailsData.DataSource = dataTable;
        }

        //Click back button to load AdminTask Form
        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminTasksHandlerForm adminTasksHandlerForm = new AdminTasksHandlerForm();
            this.Hide();
            adminTasksHandlerForm.ShowDialog();
        }

        //Insert course details to course table 
        private void btnInsert_Click(object sender, EventArgs e)
        {

            if (isValid())
            {
                try
                {
                    SqlCommand sqlCommand = new SqlCommand("INSERT INTO Course VALUES (@CourseId,@CourseType,@CourseDetails,@CourseAmount,@LectureDetails)", sqlConnection);
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.AddWithValue("@CourseId", txtCourseId.Text);
                    sqlCommand.Parameters.AddWithValue("@CourseType", comBoxCourseType.SelectedItem.ToString());
                    sqlCommand.Parameters.AddWithValue("@CourseDetails", txtCourseDetails.Text);
                    sqlCommand.Parameters.AddWithValue("@CourseAmount", txtAmount.Text);
                    sqlCommand.Parameters.AddWithValue("@LectureDetails", txtLectureDetails.Text);

                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                    MessageBox.Show("New course succesfully save in Database", "Saved!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    CourseHandlingForm courseHandlingForm = new CourseHandlingForm();

                    getCourseRecords();
                    courseHandlingForm.Show();
                    this.Dispose(false);
                    clearData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please enter valid course informations ", "Do Validation?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

        }

        //Clear course details from the textboxes
        private void clearData()
        {
            txtCourseId.Text = "";
            comBoxCourseType.SelectedItem = "";
            txtCourseDetails.Text = "";
            txtAmount.Text = "";
            txtLectureDetails.Text = "";

        }

        //Check the validation of the textbox values 
        private bool isValid()
        {
            if (txtCourseId.Text == "" || txtCourseDetails.Text == "" || txtAmount.Text == "" || txtLectureDetails.Text == "")
            {
                MessageBox.Show("Empty Texts are required!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        //Clear the data in textbox clicking the RESET button
        private void btnReset_Click(object sender, EventArgs e)
        {
            clearData();
        }

        //Delete course details 
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(txtCourseId.Text == ""))
                {
                    SqlCommand sqlCommand = new SqlCommand("DELETE FROM Course WHERE CourseId = @UpdateId", sqlConnection);
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtCourseId.Text);

                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Course details deleted ", "Deleted!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    CourseHandlingForm courseHandlingForm = new CourseHandlingForm();

                    getCourseRecords();
                    courseHandlingForm.Show();
                    this.Dispose(false);
                    clearData();

                }
                else
                {
                    MessageBox.Show("Please select a course Id  to delete course informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter valid course informations ", "Do Validation?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Update course details
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!(txtCourseId.Text == ""))
                {
                    SqlCommand sqlCommand = new SqlCommand("UPDATE Course SET CourseId = @CourseId,CourseType = @CourseId,CourseDetails = @CourseDetails,CourseAmount = @CourseAmount,LectureDetails = @LectureDetails WHERE CourseId = @UpdateId", sqlConnection);
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.Parameters.AddWithValue("@CourseId", txtCourseId.Text);
                    sqlCommand.Parameters.AddWithValue("@CourseType", comBoxCourseType.SelectedItem.ToString());
                    sqlCommand.Parameters.AddWithValue("@CourseDetails", txtCourseDetails.Text);
                    sqlCommand.Parameters.AddWithValue("@CourseAmount", txtAmount.Text);
                    sqlCommand.Parameters.AddWithValue("@LectureDetails", txtLectureDetails.Text);
                    sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtCourseId.Text);


                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Member informations updated succesfully", "Updated!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    CourseHandlingForm courseHandlingForm = new CourseHandlingForm();

                    getCourseRecords();
                    courseHandlingForm.Show();
                    this.Dispose(false);
                    clearData();
                }
                else
                {
                    MessageBox.Show("Please select a Course ID to update course informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter valid course informations ", "Do Validation?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Get values to textboxes from course table when clicking row
        private void CourseDetailsData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult dialogUpdate = MessageBox.Show("Select!!", "Do you want to UPDATE information??", MessageBoxButtons.YesNo);
            if (dialogUpdate == DialogResult.Yes)
            {
                getCourseData(e);
            }
            else if (dialogUpdate == DialogResult.No)
            {
                DialogResult dialogDelete = MessageBox.Show("Select!!", "Do you want to DELETE information??", MessageBoxButtons.YesNo);

                if (dialogDelete == DialogResult.Yes)
                {
                    txtCourseId.Enabled = false;
                    txtCourseDetails.Enabled = false;
                    comBoxCourseType.Enabled = false;
                    txtAmount.Enabled = false;
                    txtLectureDetails.Enabled = false;

                    getCourseData(e);
                }
                else if (dialogDelete == DialogResult.No)
                {
                    MessageBox.Show("OK Bye!!", "Got It!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
            }
        }

        //Get data to update and delete
        private void getCourseData(DataGridViewCellEventArgs e)
        {
            txtCourseId.Text = CourseDetailsData.Rows[e.RowIndex].Cells["CourseId"].FormattedValue.ToString();
            comBoxCourseType.Text = CourseDetailsData.Rows[e.RowIndex].Cells["CourseType"].FormattedValue.ToString();
            txtCourseDetails.Text = CourseDetailsData.Rows[e.RowIndex].Cells["CourseDetails"].FormattedValue.ToString();
            txtAmount.Text = CourseDetailsData.Rows[e.RowIndex].Cells["CourseAmount"].FormattedValue.ToString();
            txtLectureDetails.Text = CourseDetailsData.Rows[e.RowIndex].Cells["LectureDetails"].FormattedValue.ToString();
        }
    }
}
