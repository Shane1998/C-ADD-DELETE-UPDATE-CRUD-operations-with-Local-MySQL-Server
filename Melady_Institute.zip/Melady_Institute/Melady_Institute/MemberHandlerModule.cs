﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
using System.Linq;

namespace Melady_Institute
{
    public partial class MemberHandlingForm : Form
    {
        /**
         MemberHandlingForm Define :-
            1. Load the form
            2. Insert member details
            3. Update member details
            4. Delete member details
            5. Search members using memberID
         */

        // Member handling form loading
        public MemberHandlingForm()
        {
            InitializeComponent();
        }

        //Member handling form loading and load member data to gridview
        private void MemberHandlingForm_Load(object sender, EventArgs e)
        {
            getMemberRecordData();
        }

        //Sql Data connection build
        SqlConnection sqlConnection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\shane jayasinghe\source\repos\Melady_Institute\Melady_Institute\MeladyDB.mdf; Integrated Security = True");
        
        //Datatable View
        DataTable dataTable = new DataTable();

        //Get member records from member database
        private void getMemberRecordData()
        {
            SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Member", sqlConnection);
           
            sqlConnection.Open();

            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dataTable.Load(sqlDataReader);
            sqlConnection.Close();

            MemberRecordData.DataSource = dataTable;
        }
        
        //Adding member details to Member table using INSERT query
        private void btnInsert_Click(object sender, EventArgs e)
        {
            //Call the validation method to validate inserting values
            if (isValid()) {

                SqlCommand sqlCommand = new SqlCommand("INSERT INTO Member VALUES (@MemberId,@FirstName,@Surname,@Address,@Contactnumber,@Age)", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@MemberId",txtMemberId.Text);
                sqlCommand.Parameters.AddWithValue("@FirstName",txtFName.Text);
                sqlCommand.Parameters.AddWithValue("@Surname", txtSurname.Text);
                sqlCommand.Parameters.AddWithValue("@Address", txtAddress.Text);
                sqlCommand.Parameters.AddWithValue("@Contactnumber", txtContactNumber.Text);
                sqlCommand.Parameters.AddWithValue("@Age", txtAge.Text);

                sqlConnection.Open();
                try {
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("New member succesfully save in Database", "Saved!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    MemberHandlingForm memberHandlingForm = new MemberHandlingForm();

                    getMemberRecordData();
                    memberHandlingForm.Show();
                    this.Dispose(false);
                    clearData();
                }
                catch (Exception) {
                    MessageBox.Show("Entry is required!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clearData(); 
                }
            }
        }

        //Validation method
        private bool isValid()
        {
            if (txtMemberId.Text == string.Empty || txtFName.Text == string.Empty || txtSurname.Text == string.Empty || txtAddress.Text == string.Empty || txtContactNumber.Text == string.Empty || txtAge.Text == string.Empty)
            {
                MessageBox.Show("Member Details required!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        //Clear Member details from the textboxes
        private void btnReset_Click(object sender, EventArgs e)
        {
            clearData();
        }

        //Clear Data Method
        private void clearData()
        {
            txtMemberId.Clear();
            txtFName.Clear();
            txtSurname.Clear();
            txtAddress.Clear();
            txtContactNumber.Clear();
            txtAge.Clear();
        }

        //Click the table row and upload values to the textboxes
        private void MemberRecordData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult dialogUpdate = MessageBox.Show("Select!!", "Do you want to UPDATE information??", MessageBoxButtons.YesNo);
            if (dialogUpdate == DialogResult.Yes)
            {
                getDataToTextboxes();
            }
            else if (dialogUpdate == DialogResult.No)
            {
                DialogResult dialogDelete = MessageBox.Show("Select!!", "Do you want to DELETE information??", MessageBoxButtons.YesNo);
                
                if (dialogDelete == DialogResult.Yes) {
                    txtMemberId.Enabled = false;
                    txtFName.Enabled = false;
                    txtSurname.Enabled = false;
                    txtAddress.Enabled = false;
                    txtContactNumber.Enabled = false;
                    txtAge.Enabled = false;

                    getDataToTextboxes();

                } else if (dialogDelete == DialogResult.No) {
                    MessageBox.Show("OK Bye!!", "Got It!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }


        }

        //Get date when cell click
        private void getDataToTextboxes() {

            txtMemberId.Text = MemberRecordData.SelectedRows[0].Cells[0].Value.ToString();
            txtFName.Text = MemberRecordData.SelectedRows[0].Cells[1].Value.ToString();
            txtSurname.Text = MemberRecordData.SelectedRows[0].Cells[2].Value.ToString();
            txtAddress.Text = MemberRecordData.SelectedRows[0].Cells[3].Value.ToString();
            txtContactNumber.Text = MemberRecordData.SelectedRows[0].Cells[4].Value.ToString();
            txtAge.Text = MemberRecordData.SelectedRows[0].Cells[5].Value.ToString();
        }

        //Update member details
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!(txtMemberId.Text == ""))
            {
                SqlCommand sqlCommand = new SqlCommand("UPDATE Member SET MemberId = @MemberId,FirstName = @FirstName,Surname = @Surname,Address = @Address,Contactnumber = @Contactnumber,Age = @Age WHERE MemberId = @UpdateId", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@MemberId", txtMemberId.Text);
                sqlCommand.Parameters.AddWithValue("@FirstName", txtFName.Text);
                sqlCommand.Parameters.AddWithValue("@Surname", txtSurname.Text);
                sqlCommand.Parameters.AddWithValue("@Address", txtAddress.Text);
                sqlCommand.Parameters.AddWithValue("@Contactnumber", txtContactNumber.Text);
                sqlCommand.Parameters.AddWithValue("@Age", txtAge.Text);
                sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtMemberId.Text);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();

                MessageBox.Show("Member informations updated succesfully", "Updated!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                MemberHandlingForm memberHandlingForm = new MemberHandlingForm();

                getMemberRecordData();
                memberHandlingForm.Show();
                this.Dispose(false);
                clearData();
            }
            else {
                MessageBox.Show("Please select a student to update his/her informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Delete Member details
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!(txtMemberId.Text == ""))
            {
                SqlCommand sqlCommand = new SqlCommand("DELETE FROM Member WHERE MemberId = @UpdateId", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtMemberId.Text);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();

                MessageBox.Show("Member is deleted from the system", "Deleted!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                MemberHandlingForm memberHandlingForm = new MemberHandlingForm();

                getMemberRecordData();
                memberHandlingForm.Show();
                this.Dispose(false);
                clearData();
            }
            else
            {
                MessageBox.Show("Please select a student to delete his/her informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Search member details using member ID
        private void txtSearchId_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = MemberRecordData.DataSource;
            bs.Filter = MemberRecordData.Columns[0].HeaderText.ToString() + " LIKE '%" + txtSearchId.Text + "%'";
            MemberRecordData.DataSource = bs;
        }

        //Button click for go admin task manager
        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminTasksHandlerForm adminTasksHandlerForm = new AdminTasksHandlerForm();
            this.Hide();
            adminTasksHandlerForm.ShowDialog();
        }
        
    }
}
