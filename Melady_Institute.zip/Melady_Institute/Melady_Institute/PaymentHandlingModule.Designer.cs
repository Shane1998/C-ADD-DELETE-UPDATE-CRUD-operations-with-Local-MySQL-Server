﻿namespace Melady_Institute
{
    partial class PaymentHandlingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblExpiringDate = new System.Windows.Forms.Label();
            this.lblPaidDate = new System.Windows.Forms.Label();
            this.dateTimePickerPaid = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerExpire = new System.Windows.Forms.DateTimePicker();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.MembersDataView = new System.Windows.Forms.DataGridView();
            this.PaymentDataView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.comboBoxPaymentType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblIncome = new System.Windows.Forms.Label();
            this.lblTotalIcome = new System.Windows.Forms.Label();
            this.txtIncome = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.MembersDataView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentDataView)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(79, 356);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(77, 20);
            this.lblAmount.TabIndex = 0;
            this.lblAmount.Text = "Amount : ";
            // 
            // lblExpiringDate
            // 
            this.lblExpiringDate.AutoSize = true;
            this.lblExpiringDate.Location = new System.Drawing.Point(40, 448);
            this.lblExpiringDate.Name = "lblExpiringDate";
            this.lblExpiringDate.Size = new System.Drawing.Size(116, 20);
            this.lblExpiringDate.TabIndex = 1;
            this.lblExpiringDate.Text = "Expiring Date : ";
            // 
            // lblPaidDate
            // 
            this.lblPaidDate.AutoSize = true;
            this.lblPaidDate.Location = new System.Drawing.Point(69, 401);
            this.lblPaidDate.Name = "lblPaidDate";
            this.lblPaidDate.Size = new System.Drawing.Size(87, 20);
            this.lblPaidDate.TabIndex = 2;
            this.lblPaidDate.Text = "Paid Date :";
            // 
            // dateTimePickerPaid
            // 
            this.dateTimePickerPaid.Location = new System.Drawing.Point(176, 395);
            this.dateTimePickerPaid.Name = "dateTimePickerPaid";
            this.dateTimePickerPaid.Size = new System.Drawing.Size(271, 26);
            this.dateTimePickerPaid.TabIndex = 3;
            this.dateTimePickerPaid.ValueChanged += new System.EventHandler(this.dateTimePickerPaid_ValueChanged);
            // 
            // dateTimePickerExpire
            // 
            this.dateTimePickerExpire.Location = new System.Drawing.Point(176, 448);
            this.dateTimePickerExpire.Name = "dateTimePickerExpire";
            this.dateTimePickerExpire.Size = new System.Drawing.Size(271, 26);
            this.dateTimePickerExpire.TabIndex = 4;
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(176, 356);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.Size = new System.Drawing.Size(271, 26);
            this.txtAmount.TabIndex = 5;
            // 
            // MembersDataView
            // 
            this.MembersDataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MembersDataView.Location = new System.Drawing.Point(510, 45);
            this.MembersDataView.Name = "MembersDataView";
            this.MembersDataView.RowHeadersWidth = 62;
            this.MembersDataView.RowTemplate.Height = 28;
            this.MembersDataView.Size = new System.Drawing.Size(753, 270);
            this.MembersDataView.TabIndex = 6;
            this.MembersDataView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MembersDataView_CellClick);
            // 
            // PaymentDataView
            // 
            this.PaymentDataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PaymentDataView.Location = new System.Drawing.Point(510, 384);
            this.PaymentDataView.Name = "PaymentDataView";
            this.PaymentDataView.RowHeadersWidth = 62;
            this.PaymentDataView.RowTemplate.Height = 28;
            this.PaymentDataView.Size = new System.Drawing.Size(753, 270);
            this.PaymentDataView.TabIndex = 7;
            this.PaymentDataView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PaymentDataView_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Surname : ";
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(176, 187);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.ReadOnly = true;
            this.txtSurname.Size = new System.Drawing.Size(271, 26);
            this.txtSurname.TabIndex = 9;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(176, 134);
            this.txtFName.Name = "txtFName";
            this.txtFName.ReadOnly = true;
            this.txtFName.Size = new System.Drawing.Size(271, 26);
            this.txtFName.TabIndex = 10;
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(56, 140);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(98, 20);
            this.lblFName.TabIndex = 11;
            this.lblFName.Text = "First Name  :";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(56, 89);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(100, 20);
            this.lblId.TabIndex = 12;
            this.lblId.Text = "Member ID : ";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(176, 83);
            this.txtId.Name = "txtId";
            this.txtId.ReadOnly = true;
            this.txtId.Size = new System.Drawing.Size(271, 26);
            this.txtId.TabIndex = 13;
            // 
            // comboBoxPaymentType
            // 
            this.comboBoxPaymentType.AutoCompleteCustomSource.AddRange(new string[] {
            "Annual",
            "Monthly"});
            this.comboBoxPaymentType.FormattingEnabled = true;
            this.comboBoxPaymentType.Items.AddRange(new object[] {
            "Annual",
            "Monthly"});
            this.comboBoxPaymentType.Location = new System.Drawing.Point(176, 309);
            this.comboBoxPaymentType.Name = "comboBoxPaymentType";
            this.comboBoxPaymentType.Size = new System.Drawing.Size(271, 28);
            this.comboBoxPaymentType.TabIndex = 14;
            this.comboBoxPaymentType.SelectedIndexChanged += new System.EventHandler(this.comboBoxPaymentType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Payment Type :";
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(41, 523);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(170, 58);
            this.btnInsert.TabIndex = 16;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(300, 523);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(170, 58);
            this.btnDelete.TabIndex = 17;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(41, 609);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(170, 58);
            this.btnUpdate.TabIndex = 18;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(300, 609);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(170, 58);
            this.btnReset.TabIndex = 19;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(809, 339);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(264, 26);
            this.txtSearch.TabIndex = 20;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(714, 342);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 21;
            this.label3.Text = "Search ID :";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(97, 44);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblIncome
            // 
            this.lblIncome.AutoSize = true;
            this.lblIncome.ForeColor = System.Drawing.Color.Crimson;
            this.lblIncome.Location = new System.Drawing.Point(56, 254);
            this.lblIncome.Name = "lblIncome";
            this.lblIncome.Size = new System.Drawing.Size(158, 20);
            this.lblIncome.TabIndex = 23;
            this.lblIncome.Text = "Total Income (LKR) : ";
            // 
            // lblTotalIcome
            // 
            this.lblTotalIcome.AutoSize = true;
            this.lblTotalIcome.ForeColor = System.Drawing.Color.Crimson;
            this.lblTotalIcome.Location = new System.Drawing.Point(220, 254);
            this.lblTotalIcome.Name = "lblTotalIcome";
            this.lblTotalIcome.Size = new System.Drawing.Size(0, 20);
            this.lblTotalIcome.TabIndex = 24;
            // 
            // txtIncome
            // 
            this.txtIncome.Location = new System.Drawing.Point(220, 254);
            this.txtIncome.Name = "txtIncome";
            this.txtIncome.ReadOnly = true;
            this.txtIncome.Size = new System.Drawing.Size(227, 26);
            this.txtIncome.TabIndex = 25;
            // 
            // PaymentHandlingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1312, 679);
            this.Controls.Add(this.txtIncome);
            this.Controls.Add(this.lblTotalIcome);
            this.Controls.Add(this.lblIncome);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxPaymentType);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.lblFName);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PaymentDataView);
            this.Controls.Add(this.MembersDataView);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.dateTimePickerExpire);
            this.Controls.Add(this.dateTimePickerPaid);
            this.Controls.Add(this.lblPaidDate);
            this.Controls.Add(this.lblExpiringDate);
            this.Controls.Add(this.lblAmount);
            this.Name = "PaymentHandlingForm";
            this.Text = "PaymentHandlingModule";
            this.Load += new System.EventHandler(this.PaymentHandlingModule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MembersDataView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentDataView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblExpiringDate;
        private System.Windows.Forms.Label lblPaidDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerPaid;
        private System.Windows.Forms.DateTimePicker dateTimePickerExpire;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.DataGridView MembersDataView;
        private System.Windows.Forms.DataGridView PaymentDataView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.ComboBox comboBoxPaymentType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblIncome;
        private System.Windows.Forms.Label lblTotalIcome;
        private System.Windows.Forms.TextBox txtIncome;
    }
}