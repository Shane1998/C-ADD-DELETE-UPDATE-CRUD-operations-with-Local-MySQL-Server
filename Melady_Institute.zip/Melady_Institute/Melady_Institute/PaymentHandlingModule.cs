﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Melady_Institute
{
    public partial class PaymentHandlingForm : Form
    {
        /**
        PaymentHandlingForm Define :-
           1. Load the form
           2. Insert payment details
           3. Update payment details
           4. Delete payment details
           5. Search payment using memberID
           6. Get total income
        */

        public PaymentHandlingForm()
        {
            InitializeComponent();
        }

        //Sql connection builder
        SqlConnection sqlConnection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\shane jayasinghe\source\repos\Melady_Institute\Melady_Institute\MeladyDB.mdf; Integrated Security = True");
        //Datatable for payment 
        DataTable dataTablePayment = new DataTable();
        //Datatable for Member
        DataTable dataTableMember = new DataTable();

        //Payment Handling Form loading
        private void PaymentHandlingModule_Load(object sender, EventArgs e)
        {
            dateTimePickerPaid.Enabled = false;
            dateTimePickerExpire.Enabled = false;
            getRecordPayment();
            getRecordMember();
            getSumTotal();
        }

        //Payment Records loading
        private void getRecordPayment()
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Payment", sqlConnection);

                sqlConnection.Open();

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                dataTablePayment.Load(sqlDataReader);
                sqlConnection.Close();

                PaymentDataView.DataSource = dataTablePayment;
            }
            catch (Exception ex) {
                MessageBox.Show("Member Information needs to be corrected!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Member records loading
        private void getRecordMember()
        {
            SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Member", sqlConnection);

            sqlConnection.Open();

            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dataTableMember.Load(sqlDataReader);
            sqlConnection.Close();

            MembersDataView.DataSource = dataTableMember;

        }

        //Insert Payment Details 
        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (isValid())
            {

                SqlCommand sqlCommand = new SqlCommand("INSERT INTO Payment VALUES (@Id,@FName,@Sname,@PaymentType,@Amount,@PaidDate,@ExpireDate)", sqlConnection);
                try
                {
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Id", txtId.Text);
                sqlCommand.Parameters.AddWithValue("@FName", txtFName.Text);
                sqlCommand.Parameters.AddWithValue("@Sname", txtSurname.Text);
                sqlCommand.Parameters.AddWithValue("@PaymentType", comboBoxPaymentType.SelectedItem.ToString());
                sqlCommand.Parameters.AddWithValue("@Amount", txtAmount.Text);
                sqlCommand.Parameters.AddWithValue("@PaidDate", dateTimePickerPaid.Value.ToString("yyyy-MM-dd"));
                sqlCommand.Parameters.AddWithValue("@ExpireDate", dateTimePickerExpire.Value.ToString("yyyy-MM-dd"));

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                }
                catch (Exception ex) {
                    MessageBox.Show("Member Information needs to be corrected!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                sqlConnection.Close();

                MessageBox.Show("New member succesfully save in Database", "Saved!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                PaymentHandlingForm paymentHandlingForm = new PaymentHandlingForm();

                getRecordPayment();
                paymentHandlingForm.Show();
                this.Dispose(false);
                clearData();
            }
        }

        //Clear payment data in textboxes
        private void clearData()
        {
            txtId.Clear();
            txtFName.Clear();
            txtSurname.Clear();
            comboBoxPaymentType.SelectedItem = "";
            txtAmount.Clear();

        }

        //Check Invalid inputs
        private bool isValid()
        {
            if (txtId.Text == "" || txtFName.Text == "" || txtSurname.Text == "" || txtAmount.Text == "")
            {
                MessageBox.Show("Member informations are required!!!", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        //Load member details to textboxes when clicked the row
        private void MembersDataView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = MembersDataView.Rows[e.RowIndex].Cells["MemberId"].FormattedValue.ToString();
            txtFName.Text = MembersDataView.Rows[e.RowIndex].Cells["FirstName"].FormattedValue.ToString();
            txtSurname.Text = MembersDataView.Rows[e.RowIndex].Cells["Surname"].FormattedValue.ToString();
        }

        //Delete payment details
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try  
            {
                SqlCommand sqlCommand = new SqlCommand("DELETE FROM Payment WHERE Id = @UpdateId", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtId.Text);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();


                PaymentHandlingForm paymentHandlingForm = new PaymentHandlingForm();

                getRecordPayment();
                MessageBox.Show("Payment is deleted from the system", "Deleted!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                paymentHandlingForm.Show();
                this.Dispose(false);
                clearData();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please select a student to delete his/her informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Update payment details
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand("UPDATE Payment SET Id = @Id,FName = @FName,Sname = @Sname,PaymentType = @PaymentType,Amount = @Amount,PaidDate = @PaidDate,ExpireDate = @ExpireDate WHERE Id = @UpdateId", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@Id", txtId.Text);
                sqlCommand.Parameters.AddWithValue("@FName", txtFName.Text);
                sqlCommand.Parameters.AddWithValue("@Sname", txtSurname.Text);
                sqlCommand.Parameters.AddWithValue("@PaymentType", comboBoxPaymentType.SelectedItem.ToString());
                sqlCommand.Parameters.AddWithValue("@Amount", txtAmount.Text);
                sqlCommand.Parameters.AddWithValue("@PaidDate", dateTimePickerPaid.Value.ToString("yyyy-MM-dd"));
                sqlCommand.Parameters.AddWithValue("@ExpireDate", dateTimePickerExpire.Value.ToString("yyyy-MM-dd"));
                sqlCommand.Parameters.AddWithValue("@UpdateId", this.txtId.Text);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();

                MessageBox.Show("Payment informations updated succesfully", "Updated!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                PaymentHandlingForm paymentHandlingForm = new PaymentHandlingForm();

                getRecordPayment();
                paymentHandlingForm.Show();
                this.Dispose(false);
                clearData();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please select a student to update his/her informations ", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        //Load payment details to textboxes when clicked the row
        private void PaymentDataView_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            DialogResult dialogUpdate = MessageBox.Show("Select!!", "Do you want to UPDATE information??", MessageBoxButtons.YesNo);
            if (dialogUpdate == DialogResult.Yes)
            {
                getPaymentData(e);
            }
            else if (dialogUpdate == DialogResult.No)
            {
                DialogResult dialogDelete = MessageBox.Show("Select!!", "Do you want to DELETE information??", MessageBoxButtons.YesNo);

                if (dialogDelete == DialogResult.Yes)
                {
                    txtId.Enabled = false;
                    txtFName.Enabled = false;
                    txtSurname.Enabled = false;
                    txtAmount.Enabled = false;
                    comboBoxPaymentType.Enabled = false;
                    dateTimePickerPaid.Enabled = false;
                    dateTimePickerExpire.Enabled = false;

                    getPaymentData(e);
                }
                else if (dialogDelete == DialogResult.No)
                {
                    MessageBox.Show("OK Bye!!", "Got It!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        //Payment data loading
        private void getPaymentData(DataGridViewCellEventArgs e)
        {
            txtId.Text = PaymentDataView.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
            txtFName.Text = PaymentDataView.Rows[e.RowIndex].Cells["FName"].FormattedValue.ToString();
            txtSurname.Text = PaymentDataView.Rows[e.RowIndex].Cells["Sname"].FormattedValue.ToString();
            comboBoxPaymentType.Text = PaymentDataView.Rows[e.RowIndex].Cells["PaymentType"].Value.ToString();
            txtAmount.Text = PaymentDataView.Rows[e.RowIndex].Cells["Amount"].FormattedValue.ToString();
        }

        //Reset data in textboxes 
        private void btnReset_Click(object sender, EventArgs e)
        {

            PaymentHandlingForm paymentHandlingForm = new PaymentHandlingForm();

            getRecordPayment();
            paymentHandlingForm.Show();
            this.Dispose(false);
            clearData();
        }

        //Search Payment details using member ID
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = PaymentDataView.DataSource;
            bs.Filter = PaymentDataView.Columns[0].HeaderText.ToString() + " LIKE '%" + txtSearch.Text + "%'";
            PaymentDataView.DataSource = bs;
        }

        //Click back button then load AdminTask Module 
        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminTasksHandlerForm tasksHandlerForm = new AdminTasksHandlerForm();
            this.Hide();
            tasksHandlerForm.ShowDialog();
        }

        //Select Payment type and according to the type log the amount value
        private void comboBoxPaymentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxPaymentType.Text == "Annual")
            {
                txtAmount.Text = "10000";
                txtAmount.Enabled = false;
            }
            else if (comboBoxPaymentType.Text == "Monthly")
            {
                txtAmount.Text = "800";
                txtAmount.Enabled = false;
            }

            dateTimePickerPaid.Enabled = true;
        }

        //Get total Income 
        private void getSumTotal() {
            int sum = 0;
            for (int i = 0; i < PaymentDataView.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(PaymentDataView.Rows[i].Cells[4].Value);
            }
            txtIncome.Text = sum.ToString();

        }

        //Date Picker Setter for annualy paymentType & Monthly Payment Type
        private void dateTimePickerPaid_ValueChanged(object sender, EventArgs e)
        {
            dateTimePickerExpire.Enabled = false;

            if (comboBoxPaymentType.Text.Equals("Annual"))
            {
                dateTimePickerExpire.Value = dateTimePickerPaid.Value.AddYears(1); ;
            }
            else if(comboBoxPaymentType.Text.Equals("Monthly"))
            {
                dateTimePickerExpire.Value = dateTimePickerPaid.Value.AddMonths(1); ;
            }
        }
    }
}
