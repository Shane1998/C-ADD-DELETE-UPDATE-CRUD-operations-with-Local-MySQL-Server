﻿namespace Melady_Institute
{
    partial class CourseHandlingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInsert = new System.Windows.Forms.Button();
            this.lblCourseType = new System.Windows.Forms.Label();
            this.lblLectureDetails = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCourseDetails = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtCourseDetails = new System.Windows.Forms.TextBox();
            this.txtLectureDetails = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.CourseDetailsData = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            this.comBoxCourseType = new System.Windows.Forms.ComboBox();
            this.lblCourseId = new System.Windows.Forms.Label();
            this.txtCourseId = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CourseDetailsData)).BeginInit();
            this.SuspendLayout();
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(669, 76);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(136, 46);
            this.btnInsert.TabIndex = 0;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // lblCourseType
            // 
            this.lblCourseType.AutoSize = true;
            this.lblCourseType.Location = new System.Drawing.Point(275, 133);
            this.lblCourseType.Name = "lblCourseType";
            this.lblCourseType.Size = new System.Drawing.Size(110, 20);
            this.lblCourseType.TabIndex = 1;
            this.lblCourseType.Text = "Course Type : ";
            // 
            // lblLectureDetails
            // 
            this.lblLectureDetails.AutoSize = true;
            this.lblLectureDetails.Location = new System.Drawing.Point(260, 297);
            this.lblLectureDetails.Name = "lblLectureDetails";
            this.lblLectureDetails.Size = new System.Drawing.Size(128, 20);
            this.lblLectureDetails.TabIndex = 3;
            this.lblLectureDetails.Text = "Lecture Details : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(253, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Course Amount : ";
            // 
            // lblCourseDetails
            // 
            this.lblCourseDetails.AutoSize = true;
            this.lblCourseDetails.Location = new System.Drawing.Point(260, 186);
            this.lblCourseDetails.Name = "lblCourseDetails";
            this.lblCourseDetails.Size = new System.Drawing.Size(125, 20);
            this.lblCourseDetails.TabIndex = 5;
            this.lblCourseDetails.Text = "Course Details : ";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(391, 241);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(230, 26);
            this.txtAmount.TabIndex = 6;
            // 
            // txtCourseDetails
            // 
            this.txtCourseDetails.Location = new System.Drawing.Point(391, 183);
            this.txtCourseDetails.Name = "txtCourseDetails";
            this.txtCourseDetails.Size = new System.Drawing.Size(230, 26);
            this.txtCourseDetails.TabIndex = 7;
            // 
            // txtLectureDetails
            // 
            this.txtLectureDetails.Location = new System.Drawing.Point(391, 294);
            this.txtLectureDetails.Name = "txtLectureDetails";
            this.txtLectureDetails.Size = new System.Drawing.Size(230, 26);
            this.txtLectureDetails.TabIndex = 8;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(669, 205);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(136, 46);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // CourseDetailsData
            // 
            this.CourseDetailsData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CourseDetailsData.Location = new System.Drawing.Point(261, 365);
            this.CourseDetailsData.Name = "CourseDetailsData";
            this.CourseDetailsData.RowHeadersWidth = 62;
            this.CourseDetailsData.RowTemplate.Height = 28;
            this.CourseDetailsData.Size = new System.Drawing.Size(835, 271);
            this.CourseDetailsData.TabIndex = 10;
            this.CourseDetailsData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CourseDetailsData_CellClick);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(22, 23);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(121, 42);
            this.btnBack.TabIndex = 11;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // comBoxCourseType
            // 
            this.comBoxCourseType.FormattingEnabled = true;
            this.comBoxCourseType.Items.AddRange(new object[] {
            "Western Music",
            "Eastern Music",
            "Classical Music"});
            this.comBoxCourseType.Location = new System.Drawing.Point(391, 130);
            this.comBoxCourseType.Name = "comBoxCourseType";
            this.comBoxCourseType.Size = new System.Drawing.Size(230, 28);
            this.comBoxCourseType.TabIndex = 12;
            // 
            // lblCourseId
            // 
            this.lblCourseId.AutoSize = true;
            this.lblCourseId.Location = new System.Drawing.Point(286, 89);
            this.lblCourseId.Name = "lblCourseId";
            this.lblCourseId.Size = new System.Drawing.Size(89, 20);
            this.lblCourseId.TabIndex = 13;
            this.lblCourseId.Text = "Course ID :";
            // 
            // txtCourseId
            // 
            this.txtCourseId.Location = new System.Drawing.Point(391, 83);
            this.txtCourseId.Name = "txtCourseId";
            this.txtCourseId.Size = new System.Drawing.Size(230, 26);
            this.txtCourseId.TabIndex = 14;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(669, 274);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(136, 46);
            this.btnReset.TabIndex = 15;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(669, 142);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 46);
            this.btnDelete.TabIndex = 16;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // CourseHandlingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1363, 695);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtCourseId);
            this.Controls.Add(this.lblCourseId);
            this.Controls.Add(this.comBoxCourseType);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.CourseDetailsData);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtLectureDetails);
            this.Controls.Add(this.txtCourseDetails);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.lblCourseDetails);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLectureDetails);
            this.Controls.Add(this.lblCourseType);
            this.Controls.Add(this.btnInsert);
            this.Name = "CourseHandlingForm";
            this.Text = "CourseHandlingModule";
            this.Load += new System.EventHandler(this.CourseHandlingModule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CourseDetailsData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Label lblCourseType;
        private System.Windows.Forms.Label lblLectureDetails;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCourseDetails;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtCourseDetails;
        private System.Windows.Forms.TextBox txtLectureDetails;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.DataGridView CourseDetailsData;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ComboBox comBoxCourseType;
        private System.Windows.Forms.Label lblCourseId;
        private System.Windows.Forms.TextBox txtCourseId;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnDelete;
    }
}