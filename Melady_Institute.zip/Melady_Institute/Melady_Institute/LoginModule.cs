﻿using System;
using System.Windows.Forms;

namespace Melady_Institute
{
    public partial class LoginModule : Form
    {
        public LoginModule()
        {
            InitializeComponent();
        }
        
        //Username & Password Declaration and Validation method
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin") {
                AdminTasksHandlerForm adminTasksHandlerForm = new AdminTasksHandlerForm();
                this.Hide();
                adminTasksHandlerForm.ShowDialog();
            } else
            {
                MessageBox.Show("Enter Valid USERNAME & PASSWORD", "USERNAME & PASSWORD ?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
