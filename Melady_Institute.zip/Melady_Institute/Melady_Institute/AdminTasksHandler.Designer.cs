﻿namespace Melady_Institute
{
    partial class AdminTasksHandlerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMemberHandler = new System.Windows.Forms.Button();
            this.btnPaymentHandler = new System.Windows.Forms.Button();
            this.btnCourseHandler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMemberHandler
            // 
            this.btnMemberHandler.Location = new System.Drawing.Point(419, 85);
            this.btnMemberHandler.Name = "btnMemberHandler";
            this.btnMemberHandler.Size = new System.Drawing.Size(392, 116);
            this.btnMemberHandler.TabIndex = 0;
            this.btnMemberHandler.Text = "Members Handler Module";
            this.btnMemberHandler.UseVisualStyleBackColor = true;
            this.btnMemberHandler.Click += new System.EventHandler(this.btnMemberHandler_Click);
            // 
            // btnPaymentHandler
            // 
            this.btnPaymentHandler.Location = new System.Drawing.Point(419, 264);
            this.btnPaymentHandler.Name = "btnPaymentHandler";
            this.btnPaymentHandler.Size = new System.Drawing.Size(392, 116);
            this.btnPaymentHandler.TabIndex = 1;
            this.btnPaymentHandler.Text = "Payments Handler Module";
            this.btnPaymentHandler.UseVisualStyleBackColor = true;
            this.btnPaymentHandler.Click += new System.EventHandler(this.btnPaymentHandler_Click);
            // 
            // btnCourseHandler
            // 
            this.btnCourseHandler.Location = new System.Drawing.Point(419, 445);
            this.btnCourseHandler.Name = "btnCourseHandler";
            this.btnCourseHandler.Size = new System.Drawing.Size(392, 116);
            this.btnCourseHandler.TabIndex = 2;
            this.btnCourseHandler.Text = "Course Handler Module";
            this.btnCourseHandler.UseVisualStyleBackColor = true;
            this.btnCourseHandler.Click += new System.EventHandler(this.btnCourseHandler_Click);
            // 
            // AdminTasksHandlerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1229, 677);
            this.Controls.Add(this.btnCourseHandler);
            this.Controls.Add(this.btnPaymentHandler);
            this.Controls.Add(this.btnMemberHandler);
            this.Name = "AdminTasksHandlerForm";
            this.Text = "AdminTasksHandler";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMemberHandler;
        private System.Windows.Forms.Button btnPaymentHandler;
        private System.Windows.Forms.Button btnCourseHandler;
    }
}